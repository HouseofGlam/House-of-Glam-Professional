import React from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import Home from './pages/Home'
import About from './pages/About'
import Programs from './pages/Programs'
import Impact from './pages/Impact'
import ESG from './pages/ESG'
import Funding from './pages/Funding'
import Contact from './pages/Contact'

export default function App(){
  return (
    <>
      <div className="container">
        <header className="header">
          <div>
            <div className="brand">House of Glam</div>
            <div className="small">Sustainable apparel • Circular jobs • Community</div>
          </div>
          <nav className="nav">
            <Link to="/">Home</Link>
            <Link to="/about">About</Link>
            <Link to="/programs">Programs</Link>
            <Link to="/impact">Impact</Link>
            <Link to="/esg">ESG & MEL</Link>
            <Link to="/funding">Funding</Link>
            <Link to="/contact" className="button">Contact</Link>
          </nav>
        </header>

        <main>
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/about" element={<About/>} />
            <Route path="/programs" element={<Programs/>} />
            <Route path="/impact" element={<Impact/>} />
            <Route path="/esg" element={<ESG/>} />
            <Route path="/funding" element={<Funding/>} />
            <Route path="/contact" element={<Contact/>} />
          </Routes>
        </main>

        <footer className="footer">
          © {new Date().getFullYear()} House of Glam — Sustainable apparel • Circular jobs • Community
        </footer>
      </div>
    </>
  )
}
