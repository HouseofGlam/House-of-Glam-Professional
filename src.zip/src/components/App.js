export default function App() {
  return `
    <header><h1>House of Glam</h1></header>
    <section class="hero">
      <h2>Where Beauty Meets Professional Excellence</h2>
      <p>Luxury beauty, makeup artistry, wellness & executive grooming.</p>
    </section>
    <section class="director">
      <h2>Meet the Executive Director</h2>
      <img src="./assets/director.jpg" alt="Executive Director" />
      <p><strong>Naom Nyariki</strong></p>
      <p>Email: naomhopi@bbaadvocates.org</p>
      <p>Contact: +254710 858 205</p>
    </section>
  `;
}
