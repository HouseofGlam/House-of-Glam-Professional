import './style.css';
import App from './components/App.js';

document.querySelector('#app').innerHTML = App();
