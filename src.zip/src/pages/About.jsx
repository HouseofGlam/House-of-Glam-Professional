import React from 'react'

export default function About(){
  return (
    <div>
      <div className="card">
        <h2 className="section-title">Context & Problem</h2>
        <h3>Environmental</h3>
        <ul>
          <li>Textile waste overload leading to landfill and incineration impacts.</li>
          <li>High carbon & resource intensity of new clothing; reuse reduces emissions.</li>
        </ul>
        <h3>Social & Economic</h3>
        <ul>
          <li>Informal vendors and precarious livelihoods — women & youth disproportionately affected.</li>
          <li>Affordability gap and fragmented markets for quality second-hand clothing.</li>
          <li>Under-developed repair/upcycling trades that can be formalized.</li>
        </ul>
      </div>

      <div className="card" style={{marginTop:16}}>
        <h2 className="section-title">Our Mission</h2>
        <p>To build a commercial, scalable circular apparel model that reduces textile waste, creates dignified jobs and provides affordable clothing access while partnering with children’s homes and refugee centres.</p>
      </div>
    </div>
  )
}
