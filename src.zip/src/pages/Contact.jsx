import React from 'react'

export default function Contact(){
  return (
    <div>
      <div className="card">
        <h2 className="section-title">Contact & Partnerships</h2>
        <p>For partnerships, funding enquiries or media, contact our Executive Director:</p>
        <div style={{marginTop:12}}>
          <img src="/naom.jpg" alt="Naom" style={{width:140,display:'block',marginBottom:8,borderRadius:8}} />
          <h3>Naom Nyariki</h3>
          <p><strong>Executive Director</strong></p>
          <p><a href="mailto:naomhopi@bbaadvocates.org">naomhopi@bbaadvocates.org</a></p>
          <p>+254 710 858 205</p>
        </div>
        <div style={{marginTop:12}}>
          <p>If you're an investor or partner, download the full proposal (coming soon) or email Naom to request the pitch deck and financials.</p>
        </div>
      </div>
    </div>
  )
}
