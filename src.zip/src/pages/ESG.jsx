import React from 'react'

export default function ESG(){
  return (
    <div>
      <div className="card">
        <h2 className="section-title">ESG, MEL & Governance</h2>
        <h4>Environmental</h4>
        <ul>
          <li>Zero-waste target: >80% of input finds reuse/upcycle/resale pathway.</li>
          <li>KPIs: tonnes diverted, % upcycled, CO₂e avoided.</li>
        </ul>

        <h4>Social</h4>
        <ul>
          <li>Gender-inclusive hiring, vocational training, MOUs with institutions.</li>
          <li>KPIs: jobs created, income uplift, beneficiaries served.</li>
        </ul>

        <h4>Governance</h4>
        <ul>
          <li>Transparent procurement, audited reporting and data protection.</li>
        </ul>
      </div>
    </div>
  )
}
