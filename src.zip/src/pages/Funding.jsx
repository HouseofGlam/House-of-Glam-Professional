import React from 'react'

export default function Funding(){
  return (
    <div>
      <div className="card">
        <h2 className="section-title">Funding Ask & Use of Funds</h2>
        <p><strong>Total indicative ask:</strong> USD 750,000</p>
        <ol>
          <li>Processing hub setup — USD 200,000</li>
          <li>Working capital & initial inventory — USD 150,000</li>
          <li>Micro-franchise roll-out & training — USD 120,000</li>
          <li>Technology & governance systems — USD 60,000</li>
          <li>Social partnerships & program delivery — USD 50,000</li>
          <li>Upcycling workshop & product development — USD 60,000</li>
          <li>Marketing & launch — USD 30,000</li>
          <li>Operational reserves & contingency — USD 80,000</li>
        </ol>
        <p>Detailed 3-year financial model available on request.</p>
      </div>
    </div>
  )
}
