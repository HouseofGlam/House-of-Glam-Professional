import React from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <>
      <section className="hero card">
        <div className="col">
          <h1>House of Glam</h1>
          <p className="small">Commercializing sustainable apparel retail by integrating circular-economy operations (collection, sorting, repair, upcycling, resale), local micro-franchising, and social programs.</p>

          <div className="kv" style={{marginTop:16}}>
            <div><strong>50+</strong><div className="small">micro-franchise pilot partners</div></div>
            <div><strong>70–120t/mo</strong><div className="small">processing hub capacity</div></div>
            <div><strong>30–50</strong><div className="small">direct jobs (pilot)</div></div>
          </div>

          <div style={{marginTop:16}}>
            <Link to="/programs" className="button">Explore Programs</Link>
          </div>
        </div>

        <aside style={{width:320}}>
          <div style={{background:'#fff',padding:14,borderRadius:10}}>
            <img src="/naom.jpg" alt="Naom" style={{width:180,display:'block',margin:'0 auto 8px',borderRadius:10}} />
            <h3 style={{textAlign:'center'}}>Naom Nyariki</h3>
            <p style={{textAlign:'center',marginTop:6}}><strong>Executive Director</strong></p>
            <p style={{textAlign:'center',marginTop:6}}><a href="mailto:naomhopi@bbaadvocates.org">naomhopi@bbaadvocates.org</a></p>
            <p style={{textAlign:'center',marginTop:6}}>+254 710 858 205</p>
          </div>
        </aside>
      </section>

      <section style={{display:'grid',gridTemplateColumns:'1fr',gap:16,marginTop:20}}>
        <div className="card">
          <h3 className="section-title">Executive Summary</h3>
          <p>HOUSE OF GLAM commercializes sustainable apparel retail by integrating circular-economy operations (collection, sorting, repair, upcycling, resale), local micro-franchising (community resellers run branded stalls/mini-shops), and social programs (skills training, employment, and donations for children’s homes). The enterprise generates revenue through retail sales, repair/upcycle services, micro-franchise fees and recurring subscriptions while delivering measurable environmental and social impact.</p>
        </div>
      </section>
    </>
  )
}
