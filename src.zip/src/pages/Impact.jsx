import React from 'react'

export default function Impact(){
  return (
    <div>
      <div className="card">
        <h2 className="section-title">Impact & Theory of Change</h2>
        <p>If HOUSE OF GLAM processes clothing, builds repair/upcycling capacity and empowers micro-franchisees while partnering with children's homes and refugee centres, then textile waste will decrease and incomes for vulnerable groups will rise.</p>

        <h4>Targets (12–18 months)</h4>
        <ul>
          <li>Sorting hub processing 70–120 tonnes/month</li>
          <li>50 micro-franchisees trained</li>
          <li>500 beneficiaries reached in partner institutions</li>
          <li>30–50 direct jobs created</li>
        </ul>
      </div>
    </div>
  )
}
