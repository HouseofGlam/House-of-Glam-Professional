import React from 'react'

export default function Programs(){
  return (
    <div>
      <div className="card">
        <h2 className="section-title">Programs & Operations</h2>
        <h4>1. Sourcing & Procurement</h4>
        <p>Source from: (A) donated clothing, (B) ethically procured second-hand lots, (C) sustainable/recycled fabric lines. Each batch is logged with metadata and MOUs with partners.</p>

        <h4>2. Sorting, Grading & Hygiene</h4>
        <p>Items are graded A–D, cleaned, minor repairs made, and hygiene certification applied. SOPs and digital tagging ensure traceability.</p>

        <h4>3. Repair, Tailoring & Upcycling</h4>
        <p>On-site workshop produces repaired and upcycled goods with apprenticeships and KPI tracking.</p>

        <h4>4. Micro-Franchise Model</h4>
        <p>Recruit women & youth as franchise partners; provide starter kits, training, POS and inventory support.</p>

        <h4>5. Retail & Channels</h4>
        <p>Flagship stores, micro-franchise kiosks, mobile vending carts and curated subscription boxes.</p>

        <h4>6. Partnerships with Children’s Homes & Refugee Centres</h4>
        <p>Structured allocations under MOUs with hygiene standards and training access.</p>
      </div>
    </div>
  )
}
